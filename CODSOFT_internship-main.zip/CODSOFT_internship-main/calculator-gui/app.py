#!/usr/bin/env python3
from gui import GUI

class App(GUI):
    pass

App()